from base64 import encode
import socket
from turtle import update
from Otaupdate import OTAupdate
from threading import Thread
import datetime
import os
import argparse
import sys
import signal
import time

# def downloadprogress(progress):
#     print(progress)

class Server:
    def __init__(self) -> None:
        self.old_version_number =   100
        self.isButtonPressed    =   1
        self.OTA_object         =   OTAupdate()
        self.host               =   "10.1.0.191"
        self.port               =   12345
        self.running            =   0
        self.conn               =   None
        self.addr               =   None
        self.seprator           = ":"
        self.OTA_object.create_directory()
        self.update_mode        = 0
        self.data_recieve       = ""
        self.update_complete    = True
        
        
    def signal_handler(self,sig, frame):
        self.running=0
        print('You pressed Ctrl+C!')
        
    def socket_thread(self):
        self.server_socket=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) #use this to avoid port already use error
        self.server_socket.bind((self.host,self.port))
        print("Server listening on port %s" % self.port)
        self.server_socket.listen(2)
        #self.server_socket.timeout(5)
        while self.running!=0:
            print("thrread==")
            if (self.conn==None):
                try:
                    (self.conn, self.addr) = self.server_socket.accept()
                    print("client is at", self.addr[0], "on port", self.addr[1])
                except socket.timeout as e:
                    print("Waiting for Connection...")

                except Exception as e:
                    print("Connect exception: " + str(e))
            if self.conn!=None :
               # self.conn.settimeout(5)
                while self.data_recieve != "done" and self.running!=0:
                    try:
                        print("waiting for update ...")
                        self.data_recieve= self.conn.recv(1024).decode('utf-8')
                        if(self.data_recieve):
                            self.update_complete=False
                    except Exception as e:
                        print("socket Erro:" + repr(e))
                    
                    if(not self.update_complete):
                        try:
                            self.data_recieve=self.data_recieve.split(":")
                            self.old_version_number=int(self.data_recieve[0])
                            self.update_type=self.data_recieve[1]
                            self.update_mode=int(self.data_recieve[2])
                            print("information recv",self.data_recieve)
                            self.conn.send(bytes(("t"),encoding= 'utf-8'))
                            resp=self.conn.recv(1024).decode('utf-8')  

                            if((self.update_mode==1) and (resp == 't')):   # new update # for downloading ,button pressure

                                    self.latest_version,file_name=self.OTA_object.fetchlatestvesion(self.update_type,self.update_mode)
                                    print("fetch lates version file name=",self.latest_version,file_name)
                                    if(self.latest_version>self.old_version_number and self.isButtonPressed):
                                        old_version_number=self.latest_version
                                        self.OTA_object.download(file_name)

                                        filesize   = os.stat(self.OTA_object.local_download_path).st_size
                                        self.conn.send(bytes((self.OTA_object.ota_file_name + self.seprator
                                            + str(filesize)),encoding= 'utf-8'))
                                    elif(self.latest_version==old_version_number):
                                        self.sendErrorMsg("b")
                                        self.update_complete=True 

                                    resp=self.conn.recv(1024).decode('utf-8')  
                                    if(resp=="t"):
                                        print("Ack recieved for file information")
                                        filesize   = os.stat(self.OTA_object.local_download_path).st_size
                                        print(filesize,self.OTA_object.local_download_path,self.latest_version)
                                        self.sendfile(self.OTA_object.local_download_path,int(filesize)) 
                                        resp=self.conn.recv(1024).decode('utf-8')
                                        if(resp=="t"):
                                            print("file is verified at client side")
                                            self.update_complete=True 
                            #for rollback 
                            elif(self.update_mode==0):   #rollback version Number
                                __filename=self.OTA_object.fileInformation(self.update_type,self.update_mode)  
                                if(__filename is not None):
                                    print("rollbackfilename",__filename)
                                    __filesize=os.path.getsize(__filename)
                                    self.conn.send(bytes((__filename + self.seprator
                                            + str(__filesize)),encoding= 'utf-8'))
                                    resp=self.conn.recv(1024).decode('utf-8')  
                                    if(resp=="t"):
                                        print("Ack recieved for file information")
                                        self.sendfile(__filename,__filesize) 
                                        resp=self.conn.recv(1024).decode('utf-8')
                                        if(resp=="t"):
                                            print("file is verified at client side")
                                            self.update_complete=True
                                if(__filename is None):
                                    self.sendErrorMsg("n")
                                    self.update_complete=True
                            elif(self.update_mode==2):
                                self.latest_version,file_name=self.OTA_object.fetchlatestvesion(self.update_type,self.update_mode)
                                if(self.latest_version>self.old_version_number):
                                    print("New Version is availlable",self.latest_version)
                                    self.sendErrorMsg("a")
                                    self.update_complete=True

                        except Exception as e:
                            print("Exception",e)    
                        #percent=self.downloadprogress(100)
                       
                        
                        #self.get_latestVersion()
                    # elif((self.running==0) or (time()-connect_start())):
                    #     print("Tried of waiting on connection")
                    #     self.data_recieve="done"

        print("closing listener")
        self.server_socket.close()

    def downloadprogress(self):      
        #if(progress==100):
        print("downlaodeded successfully from cloud")
        
        print(os.path.getsize(self.OTA_object.local_download_path))
            #self.OTA_object.local_download_path="/home/samar/Documents/OTA/AWS/ota_update/Firmware/500.zip"
        filesize   = os.stat(self.OTA_object.local_download_path).st_size
        print(filesize,self.OTA_object.local_download_path,self.latest_version)
        
        self.conn.send(bytes((self.OTA_object.local_download_path + self.seprator
                            + str(filesize)),encoding= 'utf-8'))
       # self.sendfile(self.OTA_object.local_download_path,int(filesize))

    def sendErrorMsg(self,msg):
        self.conn.send(bytes((msg
                            ),encoding= 'utf-8'))

    # send file to client 
    def sendfile(self,filename,filesize):
        percent=0
        cycles=filesize/1024      
        with open(filename, "rb") as f:
                
                while True:
                    if(int(percent) >= 100):
                        print("File Sent to local client")
                        self.conn is None
                        break
                    # read the bytes from the file
                    bytes_read = f.read(1024)
                    # we use sendall to assure transimission in 
                    # busy networks
                    #print("byte send 0")
                    self.conn.send(bytes_read)
                    percent+= (100/cycles)
        # if(int(percent) >= 100):
        #     # self.data_recieve="done"
                    

    def get_latestVersion(self,downloadprogress):
        if(self.update_mode==1):
            self.latest_version,file_name=self.OTA_object.fetchlatestvesion(self.update_type,self.update_mode)
            print("fetch lates version file name=",self.latest_version,file_name)
            if(self.latest_version>self.old_version_number and self.isButtonPressed):
                old_version_number=self.latest_version
                self.OTA_object.download(file_name,downloadprogress)
            elif(self.latest_version>self.old_version_number and (not self.isButtonPressed)):
                print("New Version is availlable")
                self.sendErrorMsg("V3")
            elif(self.latest_version==old_version_number):
                self.sendErrorMsg("V2")
        else:
            __filename=self.OTA_object.fileInformation(self.update_type,self.update_mode)  
            if(__filename is not None):
                print("rollbackfilename",__filename)
                __filesize=os.path.getsize(__filename)
                self.sendfile(__filename,__filesize)
            else:
                print("Only one version is available")
                self.sendErrorMsg("V1")
                self.data_recieve="done"


    def startc(self):
        if self.running == 0:
            print("Starting thread")
            self.running = 1
            self.thread = Thread(target=self.socket_thread)
            self.thread.start()
            print("After the start")
            # signal.signal(signal.SIGINT, self.signal_handler)
            # signal.signal(signal.SIGTSTP, self.signal_handler)
            self.thread.join()
            print("now shutting down")
            sys.exit(0)
            
        else:
            print("thread already started.")
    def stopc(self):
        if self.running:
            print("stopping thread...")
            self.running = 0
            self.thread.join()

        else:
            print("thread not running")



    
def windows():

    server_object=Server() 
    server_object.startc()
    #server_object.get_latestVersion()
    

windows()
#server_object.get_latestVersion()
