import logging
from urllib import response
import boto3
from botocore.exceptions import ClientError
import os
from secret_keys import access_key, secret_access_key
import datetime

s3_client=boto3.client('s3', aws_access_key_id = access_key, aws_secret_access_key = secret_access_key)

config = {
    'access_key': 'AKIAYLQ34C3L3I7FQ4TD',
    'secret_key': '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',
    'region': 'ap-south-1',

    'bucketName': 'otaupdatefile'
}


class Uploadfile:
    def __init__(self) -> None:
        #TODO : developer need to change the below name as per the package name
        self._filename="2.2.1.zip"
        self._size=float(os.path.getsize(self._filename))
        self._seen_so_far=0
        self.s3_bucket='otaupdatefile'
        self.region_name='ap-south-1'
        self.table_name='ota_package'
        self.aws_access_key_id=access_key
        self.aws_secret_access_key=secret_access_key 
        self.s3_client=boto3.client('s3', aws_access_key_id = self.aws_access_key_id, aws_secret_access_key =self.aws_secret_access_key)
        self.client_dynamo=boto3.resource('dynamodb',aws_access_key_id = self.aws_access_key_id, aws_secret_access_key = self.aws_secret_access_key,region_name=self.region_name)
        self.table=self.client_dynamo.Table(self.table_name)
        self.s3_software_folder_name="OTA_Package"
        self.s3_firmware_folder_name="Firmware"
        self.s3_os_folder_name="OS"
        self.version_number = self._filename.replace(".zip","")
        self.file_extention=".zip"
        self.object_name=self.s3_software_folder_name + "/" + self._filename
        self.update_type="OS"


    def progressPercentage(self,bytes_amount):
        print(bytes_amount)
        self._seen_so_far += bytes_amount
        percentage = (self._seen_so_far / self._size) * 100
        if(int(percentage>=100)):
                self.uploadVersion()

    def uploadVersion(self):
            response=self.table.put_item(
                                    Item={
                                            'package_version':      self.version_number,
                                            'package_name' : "ota",
                                            'file_name':   "OTA_Package" + "/" + self.version_number + self.file_extention,
                                            'Firmware':        "xxx",
                                            'OS':              "xxx",
                                            'Software':         "xxx",
                                            'CreatedAt' :       str(datetime.datetime.now())})
            if(response):
                print("successfully uploaded")


    def uploadfile(self):
        if self.object_name is None:
            self.object_name=os.path.basename(self._filename)
        try:
            with open(self._filename, "rb") as f:
                self.s3_client.upload_fileobj(f, self.s3_bucket, self.object_name,Callback=self.progressPercentage)
               
        except ClientError as e:
            logging.error(e)
            return False
        return True

uploadfile_object=Uploadfile()
uploadfile_object.uploadfile()



    # s3 = boto3.client('s3')
    # with open("FILE_NAME", "rb") as f:
    #     s3.upload_fileobj(f, "BUCKET_NAME", "OBJECT_NAME")
