import threading
from Otaupdate import OTAupdate
import logging
import traceback
from app_macros import *
import os
import hashlib
from queue import Empty

logger = logging.getLogger()

class OtaThread(threading.Thread):
    def __init__(self, main_obj):
        threading.Thread.__init__(self)
        self.fota_class_object = main_obj
        self.OTA_object = OTAupdate()
        self.OTA_object.create_directory()

    def keys_exists(self, dJSONMsg, *strKeys):
        '''
        Check if *strKeys (nested) exists in input dJSONMsg (dict).
        '''
        try:
            if not isinstance(dJSONMsg, dict):
                logger.error('keys_exists() expects dict as first argument.')
                return False
            if len(strKeys) == 0:
                logger.error('keys_exists() expects at least two arguments, one given.')
                return False

            _element = dJSONMsg
            for key in strKeys:
                try:
                    _element = _element[key]
                except KeyError:
                    return False
        except Exception as e:
            logger.error("Failed to check key exists in dictonary: {0} error: {1}".format(dJSONMsg,e))
            logger.error(traceback.format_exc())
            return False

        return True

    def getMD5SUMofFile(self, strFileName):
        strMD5SUM = None
        try:
            with open(strFileName, 'rb') as file_to_check:
                #TODO: Need to think file read logic in case of file is big
                # read contents of the file
                data = file_to_check.read()    
                # pipe contents of the file through
                strMD5SUM = str(hashlib.md5(data).hexdigest())
        except Exception as e:
            logger.error("Failed to calculate the MD5SUM of file: {0} error: {1}".format(strFileName,e))
            logger.error(traceback.format_exc())
        return strMD5SUM
    
    def sendInValidJSONMessage(self, iDestinationDealerId, iMessageType):
        dJSONMsg = {}
        dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
        dJSONMsg[DESTINATION_KEY] = iDestinationDealerId
        dJSONMsg[MESSAGE_TYPE_KEY] = iMessageType
        dJSONMsg[STATUS_KEY] = ERROR_CODE_INVALID_JSON
        dJSONMsg[DATA_KEY] = {} 
        self.fota_class_object.send_data(dJSONMsg)

    def run(self):
        while(True):
            try:
                dJSONMsg = self.fota_class_object.queueHandler.get(block=True, 
                    timeout=OTA_THREAD_GET_OTA_VERSION_TIME_INTERVAL)
            except Empty:
                # Below logic will check new package avaiblity over the AWS, If new version is higher 
                # than current local version then It will download the new package from the AWS and 
                # send the new package avaiable message to backend application

                iReturnValue = self.OTA_object.fetchlatestvesion()
                if iReturnValue == SUCCESS: 
                    strLatestLocalPkgName = self.OTA_object.get_package_info(PACKAGE_LATEST)
                    if(strLatestLocalPkgName == None):
                        iLocalPkgVer = 0
                    else:
                        iLocalPkgVer = int(strLatestLocalPkgName.replace(".zip","").replace(".",""))

                    iRemotePkgVer = int(self.OTA_object.strLatestPkgVersion.replace(".",""))

                    logger.info("Local latest package version: {0} remote version: {1}".
                                format(iLocalPkgVer,iRemotePkgVer))
                    
                    if(iRemotePkgVer > iLocalPkgVer):
                        self.OTA_object.local_download_path = self.OTA_object.directory + "/" + self.OTA_object.ota_file_name
                        if True == self.OTA_object.download(self.OTA_object.ota_file_name):
                            dJSONMsg = {}
                            dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                            dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                            dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_NEW_PKG_AVAILABLE
                            dJSONMsg[DATA_KEY] = {PKG_VERSION_KEY:self.OTA_object.strLatestPkgVersion}
                            self.fota_class_object.send_data(dJSONMsg)
                        else:
                            logger.error("Failed to download latest package: {}".format(self.OTA_object.ota_file_name))
                    else:
                        logger.error("Latest package is not availalbe over the remote")
                else:
                    logger.error("Failed check latest version over the AWS")
                continue

            try:                                
                if(type(dJSONMsg) is dict):
                    logger.info("Received data: {}".format(dJSONMsg))

                    #TODO: Here we also need to check the connection status
                    if self.keys_exists(dJSONMsg, MESSAGE_TYPE_KEY):
                        if dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_NEW_UPDATE_CHECK:
                            if self.keys_exists(dJSONMsg,DATA_KEY,PKG_VERSION_KEY):
                                # TODO: Need to change code as per the perfect version number like 1.1.2 or something
                                strPkgVersion = dJSONMsg[DATA_KEY][PKG_VERSION_KEY]

                                # TODO: Is package version is required to fetch the latest version? need to think
                                iReturnValue = self.OTA_object.fetchlatestvesion(strPkgVersion)

                                logger.info("latest Package version: {0}, package name: {1}". \
                                    format(self.OTA_object.strLatestPkgVersion, self.OTA_object.strLatestPkgName))
                                dJSONMsg.clear()
                                dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                                dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                                dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_NEW_UPDATE_CHECK
                                if(iReturnValue == SUCCESS):
                                    dJSONMsg[STATUS_KEY] = SUCCESS
                                    dJSONMsg[DATA_KEY] = {PKG_VERSION_KEY: str(self.OTA_object.strLatestPkgVersion)} 
                                else:
                                    dJSONMsg[STATUS_KEY] = iReturnValue
                                    dJSONMsg[DATA_KEY] = {}
                                self.fota_class_object.send_data(dJSONMsg)
                            else:
                                self.sendInValidJSONMessage(BACKEND_DEALER_ID, MSG_TYPE_NEW_UPDATE_CHECK)
                                logger.error("package type or package version not avaialable in JSON: {0}".format(dJSONMsg)) 

                        elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_UPGRADE:
                            if self.keys_exists(dJSONMsg,DATA_KEY,PKG_VERSION_KEY):
                                
                                strPackageName = dJSONMsg[DATA_KEY][PKG_VERSION_KEY] + ".zip"

                                # TODO: Need to correct the path as per the requirement 
                                self.OTA_object.local_download_path = self.OTA_object.directory + "/" + strPackageName
                                logger.info("File download path: {0}".format(self.OTA_object.local_download_path)) 

                                #TODO: Here we need the return value of downalod status
                                if True == self.OTA_object.download(strPackageName):
                                    iFileSize   = os.stat(self.OTA_object.local_download_path).st_size
                                    logger.info("Downloaded file size: {0}".format(iFileSize))

                                    dJSONMsg.clear()
                                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                                    dJSONMsg[DESTINATION_KEY] = FOTA_STM_DEALER_ID
                                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_PKG_INFO
                                    dJSONMsg[STATUS_KEY] = SUCCESS
                                    dDataObj = {}
                                    # For package version need to remove the .zip from the package name string 
                                    dDataObj[PKG_VERSION_KEY] = strPackageName.replace(".zip","")
                                    dDataObj[PKG_NAME_KEY] = strPackageName
                                    dDataObj[PKG_TYPE_KEY] = PACKAGE_TYPE_UPGRADE
                                    dDataObj[PKG_SIZE_KEY] = iFileSize
                                    dDataObj[PKG_MD5SUM_KEY] = self.getMD5SUMofFile(self.OTA_object.local_download_path)
                                    dDataObj[PKG_LOCATION_KEY] = self.OTA_object.local_download_path
                                    dJSONMsg[DATA_KEY] = dDataObj 
                                    self.fota_class_object.send_data(dJSONMsg)
                                else:
                                    logger.info("package download failed, name: {}".format(strPackageName))
                                    dJSONMsg.clear()
                                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                                    dJSONMsg[DESTINATION_KEY] = FOTA_STM_DEALER_ID
                                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_PKG_INFO
                                    dJSONMsg[STATUS_KEY] = ERROR_CODE_PKG_DOWNLOAD_FAILED
                                    dJSONMsg[DATA_KEY] = {PKG_TYPE_KEY:PACKAGE_TYPE_UPGRADE}
                                    self.fota_class_object.send_data(dJSONMsg)
                        elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_PKG_ROLLBACK:
                            print("Got the rollback message ")
                            if self.keys_exists(dJSONMsg,DATA_KEY,PKG_VERSION_KEY):
                                # TODO: Do we really require the current version information in this message?
                                currentPkgVersion = dJSONMsg[DATA_KEY][PKG_VERSION_KEY]
                                strRollbackPkgName = self.OTA_object.get_package_info(PACKAGE_PREVIOUS)
                                print("Rollback package name: {}".format(strRollbackPkgName))
                                if None != strRollbackPkgName:
                                    dJSONMsg.clear()
                                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                                    dJSONMsg[DESTINATION_KEY] = FOTA_STM_DEALER_ID
                                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_PKG_INFO
                                    dDataObj = {}
                                    # For package version need to remove the .zip from the package name string 
                                    dDataObj[PKG_VERSION_KEY] = strRollbackPkgName.replace(".zip","")
                                    dDataObj[PKG_NAME_KEY] = strRollbackPkgName
                                    dDataObj[PKG_TYPE_KEY] = PACKAGE_TYPE_ROLLBACK
                                    dDataObj[PKG_SIZE_KEY] = os.path.getsize(self.OTA_object.local_download_path)
                                    dDataObj[PKG_MD5SUM_KEY] = self.getMD5SUMofFile(self.OTA_object.local_download_path)
                                    dDataObj[PKG_LOCATION_KEY] = self.OTA_object.local_download_path
                                    dJSONMsg[STATUS_KEY] = SUCCESS
                                    dJSONMsg[DATA_KEY] = dDataObj 
                                    self.fota_class_object.send_data(dJSONMsg)
                                else:
                                    logger.error("No Package is avaiable for the Roll Back")
                                    dJSONMsg.clear()
                                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                                    dJSONMsg[DESTINATION_KEY] = FOTA_STM_DEALER_ID
                                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_PKG_INFO
                                    dJSONMsg[STATUS_KEY] = ERROR_CODE_ROLLBACK_PKG_NOT_AVAILABLE
                                    dJSONMsg[DATA_KEY] = {PKG_TYPE_KEY:PACKAGE_TYPE_ROLLBACK}
                                    self.fota_class_object.send_data(dJSONMsg)
                        elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_ROLLBACK_FEEDBACK:
                            if self.keys_exists(dJSONMsg,DATA_KEY,PKG_VERSION_KEY) and \
                               self.keys_exists(dJSONMsg, STATUS_KEY):
                                strRollbackVersion = dJSONMsg[DATA_KEY][PKG_VERSION_KEY]
                                if dJSONMsg[STATUS_KEY] == SUCCESS:
                                    try:
                                        strRollbackPkgName = self.OTA_object.get_package_info(PACKAGE_LATEST)
                                        logger.info("Removing the latest package({}) as rollback successfull"
                                            .format(self.OTA_object.local_download_path))
                                        if(os.path.exists(self.OTA_object.local_download_path)):
                                            os.remove(self.OTA_object.local_download_path)
                                    except Exception as e:
                                        logger.error("Failed to delete the latest package: {0}".format(e))
                                        logger.error(traceback.format_exc())
                    else:
                        logger.error("msg type key not found in JSON: {0}".format(dJSONMsg))
                        # Sending the invalid JSON message with message type value 0, because message type key is
                        # not available into the received JSON message
                        self.sendInValidJSONMessage(dJSONMsg[SOURCE_KEY], 0)
                else:
                    logger.error("Received data is not dictonary, type: {0}".format(type(dJSONMsg)))
            except Exception as e:
                logger.error("JSON parsing failed: {0}".format(e))
                logger.error(traceback.format_exc())


