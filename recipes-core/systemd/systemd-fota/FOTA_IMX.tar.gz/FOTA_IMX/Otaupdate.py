from importlib.metadata import metadata
from urllib import response
import boto3
import sys
import os
import time
import datetime
import logging
from secret_key import access_key, secret_access_key
from botocore.config import Config
from boto3.dynamodb.conditions import Key, Attr
import zipfile
import traceback
from app_macros import *

logger = logging.getLogger()

class OTAupdate:
    def __init__(self) -> None:
        self.aws_access_key_id=access_key
        self.aws_secret_access_key=secret_access_key
        self.local_UI_file_name='V730i_UI.zip'
        self.local_download_path=""
        self.s3_bucket='otaupdatefile'
        self.region_name='ap-south-1'
        self.table_name='ota_package'     
        self.s3_client=boto3.client('s3', aws_access_key_id = self.aws_access_key_id, aws_secret_access_key =self.aws_secret_access_key)
        self.client_dynamo=boto3.resource('dynamodb',aws_access_key_id = self.aws_access_key_id, aws_secret_access_key = self.aws_secret_access_key,region_name=self.region_name)
        self.table=self.client_dynamo.Table(self.table_name)
        self.directory=os.path.join(os.path.dirname(os.path.realpath(__file__)), OTA_PACKAGE_DIR_NAME)
        self.file_extension=".zip"
        self.strLatestPkgName = ""
        self.strLatestPkgVersion = ""
        self.file_objec=""
        self.downloaded=0
        self.file_size=0

    # new directory create on IOMT if not exist to download the file
    def create_directory(self):
        try:
            logger.info("Creating the dictonary for OTA package: {0}".format(self.directory))
            if(not (os.path.exists(self.directory))):
                os.mkdir(self.directory)
                print("directory Created")
            else:
                print("Directory is created already")
        except Exception as e:
            logger.error("Failed to create the self.directory: {0} error: {1}".format(self.directory,e))
            logger.error(traceback.format_exc())

    #fetch lates version 
    def fetchlatestvesion(self,strCurrentPkgVersion = None):
        try:
            #response = self.table.scan()
            response = self.table.query(
                KeyConditionExpression=Key('package_name').eq("ota"),
                ScanIndexForward=False,  
                Limit=1     #top most item
            )
            #response = self.table.scan(Limit=1)

            logger.error("Response is : {0}".format(response))
            #when version is available 
            if(response['Count']>0):
                print(response['Items'])
                self.strLatestPkgName =response['Items'][0]['file_name']
                self.ota_file_name=self.strLatestPkgName.split("/")[1]
                self.strLatestPkgVersion = response['Items'][0]['package_version']
                self.local_download_path=os.path.join(self.directory,self.ota_file_name)
                #when new version available
                return SUCCESS
            else:
                return ERROR_CODE_FAILED_TO_GET_NEW_UPDATE
        except Exception as e:
            logger.error("Failed to check new update error: {1}".format(e))
            logger.error(traceback.format_exc())
            return ERROR_CODE_FAILED_TO_GET_NEW_UPDATE
    
    def get_package_info(self, iPackage):
        strReturn = None
        try:
            os.chdir(self.directory)
            # last element of below list is latest created file
            file_list = sorted(filter(os.path.isfile, os.listdir(".")), key=os.path.getmtime)
            if len(file_list) > 0:
                # Reverse the list to make latest file as first element
                file_list.reverse()
                logger.debug("Sorted file list in OTA directory: {}".format(file_list))

                if(iPackage == PACKAGE_LATEST):
                    strReturn = file_list[0]
                    self.local_download_path=os.path.join(self.directory,file_list[0])
                else:
                    # Check the list size, because to get the previous verison file, we need atleat two files
                    if(len(file_list) > 1):
                        strReturn = file_list[1]
                        self.local_download_path=os.path.join(self.directory,file_list[1])
            else:
                pass
        except Exception as e:
            logger.error("Failed to get package information: {1}".format(e))
            logger.error(traceback.format_exc())
        return strReturn

    def is_OTA_Package_downloaded(self, strPackageName):
        bReturn = False
        try:
            os.chdir(self.directory)
            # last element of below list is latest created file
            file_list = sorted(filter(os.path.isfile, os.listdir(".")), key=os.path.getmtime)

            if strPackageName in file_list:
                bReturn = True

        except Exception as e:
            logger.error("Failed to get the previous version package name: {1}".format(e))
            logger.error(traceback.format_exc())
        return bReturn
    
    # TODO: We can add logic to delete the older version of OTA packages file in this function. 
    def download(self,strPackageName):

        # First check if OTA package is already downloaded
        if True == self.is_OTA_Package_downloaded(strPackageName):
            logger.info("OTA package: {} already downloaded".format(strPackageName))
            return True

        s3_object_key = OTA_PACKAGE_DIR_NAME + "/" + strPackageName
        logger.info("Prepared Object Key is: {0} pkgname: {1}".format(s3_object_key,strPackageName))
        bReturn = False
        try:
            metadata=self.s3_client.head_object(Bucket=self.s3_bucket, Key=s3_object_key) 
            total_length=int(metadata.get('ContentLength', 0))
            print("total file length = ",total_length)

            def progress(chunk):
                print(chunk)
                self.downloaded += chunk 
                print("downloaded from cloud = ",self.downloaded)
                # time.sleep(1)
                done = int(100 * self.downloaded / total_length)
                print("done=",done)
                #sys.stdout.write("\r[%s%s]" % ('=' * done, ' ' * (50-done)) )
                #sys.stdout.flush()
                #if(done==100):
                # 
                
            print(f'Downloading {s3_object_key}')
            print(self.local_download_path)
            with open(self.local_download_path, 'wb') as self.file_objec:
                self.s3_client.download_fileobj(self.s3_bucket, s3_object_key, self.file_objec, Callback=progress)

            # downloadprogress()
            print("downloaded_fileSize=",os.path.getsize(self.local_download_path))
            bReturn = True
        except Exception as e:
            logger.error("Failed to download OTA package: {0} error: {1}".format(s3_object_key, e))
            logger.error(traceback.format_exc())
        return bReturn



