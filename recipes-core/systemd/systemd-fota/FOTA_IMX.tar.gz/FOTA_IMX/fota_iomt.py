"""
 FileName      : fota_imot.py

 Description   : This file contains the implementation of FOTA_IOMT ZMQ dealer. which is reponsible to handle
                 all the incoming message from the Router application. Also sent response to that perticular message
                 with data.

 Author        : Noccarc
"""
import threading
import zmq
import subprocess 
import json
from json.decoder import JSONDecodeError
import logging
import logging.handlers
import traceback
import sys
from ota_thread import OtaThread
from queue import Queue
from app_macros import *
import time
import socket

class fota_iomt():
    """
    Class        : fota_iomt
    Inherits     :
    Description  : Main application class which is handling the ZMQ messages 
    """
    def __init__(self):
        """
        Function: __init__
        Description: init method of class
        @param:
        @return:
        """
        threading.Thread.__init__(self)
        self.name = "FOTA_IOMT"
        # Intialize the ZMQ dealer instance for the FOTA_IOMT 
        self.context = zmq.Context.instance()
        self.socket = self.context.socket(zmq.DEALER)
        self.socket.setsockopt(zmq.IDENTITY, bytes(FOTA_IOMT_DEALER_ID_STR, 'utf-8'))
        # Make connect call with the Router 
        self.socket.connect(ROUTER_SOCKET_ADDRESS)
        logging.debug("ZMQ connect request sent, dealerID: {0} socketID: {1}".format(FOTA_IOMT_DEALER_ID, zmq.IDENTITY))
        self.otaHandle = None
        # Queue intialization, which will pass the OTA related message to another thread
        self.queueHandler = Queue()

    def send_data(self, dJSONMsg):
        """
        Function: send_data
        Description: Send the JSON message to router application
        @param dJSONMsg: JSON dictonary to be sent to Router application
        @return: 
        """
        try:
            logger.info(">>>  {}".format(dJSONMsg))

            #Convert JSON message dictonary to string
            json_obj_to_send = json.dumps(dJSONMsg)
            self.socket.send_multipart([b'1', bytes(json_obj_to_send,'utf-8')])
            logger.debug("JSON message sent to the Router")
        except Exception as e:
            logger.error("Failed to send JSON message: {0} error: {1}".format(dJSONMsg,e))
            logger.error(traceback.format_exc())

    def scan_wifi(self):
        """
        Function: scan_wifi
        Description: Scan the available access points list
        @param:
        @return lWiFiListOfAPListObjects: List of accecss points objects with SSID, Security and Signal strength properties
        """
        try:
            lWiFiList = []
            lWiFiListOfAPListObjects = []
            process = subprocess.run(['nmcli', '-t', '-f', 'SSID,SECURITY,SIGNAL', 'dev', 'wifi'], stdout=subprocess.PIPE)
            if process.returncode == 0:
                result =  process.stdout.decode('utf-8').strip().split('\n')
            
            # parse the command output and prepare the wifi list for each access points
            for each in result:
                if not each.startswith(":"):
                    data = each.split(":")
                    if(False == any(data[0] in i for i in lWiFiList)):
                        lWiFiList.append(data)
                        lWiFiListOfAPListObjects.append({SSID_KEY:data[0], SECURITY_KEY:data[1], SIGNAL_KEY:int(data[2])})

            logger.debug("Acess points data in list: {}".format(lWiFiListOfAPListObjects))

        except Exception as e:
            logger.error("Failed to fetch the wifi list, error: {1}".format(e))
            logger.error(traceback.format_exc())

        return lWiFiListOfAPListObjects
    
    def check_internet(self):
        """
        Function: check_internet
        Description: Check internet connectivity of connected access point
        @param:
        @return: True if access point have internet connectiviy otherwise False
        """
        try:
            # see if we can resolve the host name -- tells us if there is
            # a DNS listening
            host = socket.gethostbyname(REMOTE_SERVER)
            # connect to the host -- tells us if the host is actually reachable
            s = socket.create_connection((host, 80), 2)
            s.close()
            return True
        except Exception as e:
            logger.error("Failed to check internet connectivity: {0}".format(e))
            logger.error(traceback.format_exc())
        return False
    
    def wifi_get_current_connection(self):
        """
        Function: wifi_get_current_connection  
        Description: Function to the get the name of current connected access point name, 
                     and if currently wifi is OFF then it will turn ON the wifi and send the 
                     connected access point name
        @param:
        @return: Returns the access point name in string, if device is not connected with 
                 any access point then it will return "--" string
        """
        # If there is no wifi connection then this function will return -- string
        strCurrentWiFiName = "--"
        try:
            strCommand = "nmcli dev show " + WIFI_INTERFACE_NAME
            byteOutPut = subprocess.check_output(strCommand, shell=True)
            strOutPut = byteOutPut.decode('utf-8').split("\n")
            logger.debug("Command: {0} output: {1}".format(strCommand,strOutPut))
            
            # Loop to check wifi is ON/OFF, If wifi is OFF then turn it ON
            for each in strOutPut:
                if each.startswith("GENERAL.STATE:"):
                    iCurrentWiFiStatus = int(each.replace("GENERAL.STATE:","").strip().split(" ")[0].strip()) 
                    if iCurrentWiFiStatus == NMCLI_WIFI_STATE_UNAVAILABLE:
                        logger.info("Currently wifi is OFF, turning ON the wifi")
                        subprocess.check_output("nmcli radio wifi on", shell=True)
                        time.sleep(WAIT_IN_SEC_BETWEEN_WIFI_COMMANDS*4)
            
            strCommand = "nmcli dev show " + WIFI_INTERFACE_NAME
            byteOutPut = subprocess.check_output(strCommand, shell=True)
            strOutPut = byteOutPut.decode('utf-8').split("\n")
            logger.debug("Command: {0} output: {1}".format(strCommand,strOutPut))
            # Loop to check current connected wifi name
            for each in strOutPut:
                if each.startswith("GENERAL.CONNECTION:"):
                    strCurrentWiFiName =  str(each.replace("GENERAL.CONNECTION:","").strip())
        except Exception as e:
            logger.error("Failed to get the current wifi name error: {0}".format(e))
            logger.error(traceback.format_exc())
        return strCurrentWiFiName

        """
        Function: wifi_off
        Description: Function to turn off the WiFi
        @return: wifi off command status
        """
    def wifi_off(self):
        iStatus = ERROR_CODE_FAILED_TO_OFF_WIFI
        try:
            subprocess.check_output("nmcli radio wifi off", shell=True)
            iStatus = SUCCESS
        except Exception as e:
            logger.error("Failed to turn off the wifi: {0}".format(e))
            logger.error(traceback.format_exc())   
        return iStatus

    def wifi_connect(self, ssid: str, password: str):
        """
        Function: wifi_connect
        Description: connect the device with access point as per the input arguments
        @param ssid: SSID of access point
        @param password: Password of the access point
        @return: Connection status 
                 Note: Please refer the wifi_status_code dictonary for same
        """
        wifi_connect_retry = WIFI_CONNECTION_RETRY_COUNT
        current_wifi_name = ""
        iReturn = ERROR_CODE_WIFI_CONNECT_FAILED

        try:
            current_wifi_name = self.wifi_get_current_connection()

            # If new wifi name is same as connected wifi then just check internet 
            # connectivity, No need to connect again
            if(((current_wifi_name == ssid) and (True == self.check_internet()))):
                iReturn = SUCCESS
                return iReturn      

            # wait for some time between two commands 
            time.sleep(WAIT_IN_SEC_BETWEEN_WIFI_COMMANDS)

            #If wifi is connected with some network, need to disconnect first
            if(current_wifi_name != "--"):
                logger.info("Currently, wifi is connected with {}".format(current_wifi_name))

                #down the current wifi connection
                strOutput = subprocess.check_output("nmcli c down id " + '"' + current_wifi_name + '"', shell=True)
                logger.debug("Output of current wifi down command: {0}".format(strOutput))

                time.sleep(WAIT_IN_SEC_BETWEEN_WIFI_COMMANDS)

                subprocess.call(['nmcli', 'd', 'disconnect', WIFI_INTERFACE_NAME])

            while(wifi_connect_retry > 0):
                # wait for some time between two commands 
                time.sleep(WAIT_IN_SEC_BETWEEN_WIFI_COMMANDS)  
                # Make wifi connect call
                subprocess.call(['nmcli', 'd', 'wifi', 'connect', ssid, 'password', password])
                
                current_wifi_name = self.wifi_get_current_connection()
                
                # break the loop if wifi connected
                if((current_wifi_name == ssid) and (True == self.check_internet())):
                    break
                else:
                    logger.info("Turning OFF and turning ON the wifi interface")
                    strCommand = "nmcli radio wifi off"
                    subprocess.check_output(strCommand, shell=True)
                    time.sleep(WAIT_IN_SEC_BETWEEN_WIFI_COMMANDS)
                    strCommand = "nmcli radio wifi on"
                    subprocess.check_output(strCommand, shell=True)
                    time.sleep(WAIT_IN_SEC_BETWEEN_WIFI_COMMANDS*4)

                wifi_connect_retry = wifi_connect_retry - 1

            current_wifi_name = self.wifi_get_current_connection()
            # check for the internet after successfull wifi connection    
            if(current_wifi_name == ssid):
                if(True == self.check_internet()):
                    iReturn = SUCCESS
                else:
                    iReturn = ERROR_CODE_WIFI_CONNECTED_NO_INTERNET
            else:
                iReturn = ERROR_CODE_WIFI_CONNECT_FAILED
        except Exception as e:
            logger.error("Failed to connect with wifi: {0}".format(e))
            logger.error(traceback.format_exc())

        return iReturn

    def run(self):
        """
        main thread
        @return:
        """
        self.otaHandle = OtaThread(self)
        self.otaHandle.start()

        dJSONMsg = {}
        dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
        dJSONMsg[DESTINATION_KEY] = ROUTER_ID
        dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_REG
        dJSONMsg[DATA_KEY] = {}

        self.send_data(dJSONMsg)
        
        # infinite while loop which is responsible to handle the all the ZMQ messages
        while True:
            logger.debug("Entering in to the infinite loop")

            # Blocking zmq received call 
            self.socket.recv()
            received_data = self.socket.recv()

            logger.info("<<< {0}".format(received_data))

            # convery received JSON message string in to the dictonary, So that we can 
            # easily read all the parameters of JSNO message
            try:
                dJSONMsg = json.loads(received_data)
            except JSONDecodeError as e:
                logger.error("JSON parsing failed: {0}".format(e))
                logger.error(traceback.format_exc())

            # TODO: First here need to check the key exists in dictonary or not, also same for 
            # each message type 
            if MESSAGE_TYPE_KEY in dJSONMsg:
                if dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_HEART_BEAT:
                    dJSONMsg.clear()
                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                    dJSONMsg[DESTINATION_KEY] = ROUTER_ID
                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_HEART_BEAT
                    dJSONMsg[STATUS_KEY] = SUCCESS
                    dJSONMsg[DATA_KEY] = {}                
                    self.send_data(dJSONMsg)
                elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_WIFI_LIST:
                    dJSONMsg.clear()
                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                    dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_WIFI_LIST
                    lWiFiList = self.scan_wifi()
                    if len(lWiFiList) == 0:
                        dJSONMsg[STATUS_KEY] = ERROR_CODE_FAILED_TO_FETCH_WIFI_LIST
                    else:
                        dJSONMsg[STATUS_KEY] = SUCCESS
                    dJSONMsg[DATA_KEY] = {ACCESS_POINT_LIST_ARRAY_KEY : lWiFiList}
                    self.send_data(dJSONMsg)
                elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_WIFI_CONNECT:
                    ssid = dJSONMsg[DATA_KEY][SSID_KEY]
                    password = dJSONMsg[DATA_KEY][PASSWORD_KEY]
                    iConnStatus = self.wifi_connect(ssid,password)
                    dJSONMsg.clear()
                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                    dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_WIFI_CONNECT
                    dJSONMsg[STATUS_KEY] = iConnStatus
                    dJSONMsg[DATA_KEY] = {WIFI_NAME_KEY:str(self.wifi_get_current_connection())}
                    self.send_data(dJSONMsg)
                elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_CONNECTED_WIFI_NAME:
                    dJSONMsg.clear()
                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                    dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_CONNECTED_WIFI_NAME
                    strWiFiName = str(self.wifi_get_current_connection())
                    if(strWiFiName == "--"):
                        dJSONMsg[STATUS_KEY] = ERROR_CODE_WIFI_NOT_CONNECTED_TO_STATION
                    else:
                        dJSONMsg[STATUS_KEY] = SUCCESS

                    dJSONMsg[DATA_KEY] = {WIFI_NAME_KEY:strWiFiName}
                    self.send_data(dJSONMsg)
                elif dJSONMsg[MESSAGE_TYPE_KEY] == MSG_TYPE_WIFI_OFF:
                    dJSONMsg.clear()
                    dJSONMsg[SOURCE_KEY] = FOTA_IOMT_DEALER_ID
                    dJSONMsg[DESTINATION_KEY] = BACKEND_DEALER_ID
                    dJSONMsg[MESSAGE_TYPE_KEY] = MSG_TYPE_WIFI_OFF
                    dJSONMsg[STATUS_KEY] = self.wifi_off()
                    dJSONMsg[DATA_KEY] = {}
                    self.send_data(dJSONMsg)
                elif dJSONMsg[MESSAGE_TYPE_KEY] in [MSG_TYPE_NEW_UPDATE_CHECK,MSG_TYPE_PKG_UPGRADE, 
                        MSG_TYPE_PKG_ROLLBACK, MSG_TYPE_ROLLBACK_FEEDBACK]:
                    self.queueHandler.put(dJSONMsg)

"""
Function: logging_setup
Description: This function setup the logging for the Application. This function takes the 
values from the logging_types dictonary. based on that it will decide where applicaiton logs 
should be print on colsole and logging file
"""
def logging_setup():
    root = logging.getLogger()
    root.setLevel(logging.INFO)

    # Print the logs in to the console, if "log_into_console" key is true
    if logging_types['log_into_console'] == True:
        ch = logging.StreamHandler(sys.stdout)
        # TODO: Here developer can decide the log level which will be print over the console
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        root.addHandler(ch)

    # Store the logs in to the file if "log_into_file" key is true
    if logging_types['log_into_file'] == True:
        log_file_handler = logging.handlers.RotatingFileHandler(LOG_FILE_NAME, maxBytes = LOG_FILE_SIZE, backupCount = LOG_FILE_BACK_COUNT)
        # TODO: Here developer can decide the log level which will stored in to the log file
        log_file_handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        log_file_handler.setFormatter(formatter)
        root.addHandler(log_file_handler)
    return root

# Logging setup
logger = logging_setup()

main_obj = fota_iomt()
main_obj.run()
