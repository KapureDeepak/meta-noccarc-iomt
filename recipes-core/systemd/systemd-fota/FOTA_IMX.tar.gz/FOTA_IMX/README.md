# FOTA_IMX application note

Note: Please change the 'self.host' variable value(Server.py file) with the IP address of the machine from where Server application is going to run.

Command to run the Server.

python3 Server.py

-------------------
File Description:
-------------------
Otaupdate.py : This file is responsible to downalod the latest firmware/Software/OS packages from the AWS cloud

secret_key.py : This file consists of keys which is required to downaload the OTA packages from the AWS cloud

Server.py : This file manages the socket communication with FOTA_STM application, use the API exposed from the Otaupdate.py file.

test_logs_fota_imx.txt : Application working logs

Upload_file_PC : python script to upload the file from PC to aws server



